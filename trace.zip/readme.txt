Team Member:
Andrew Bueide

took 2:30 till 5:54 pm to get first working version. Most of the time was spent learning basic c stuff. Like how do I open & write to files?
How do I create an array at runtime??? what is a malloc? why is there no hashmap??? ok, I'll just come up with some janky thing
using 2 arrays in place of a hashmap. Okay, done but the program just keeps running and won't stop. Fix some performance
issues, bam. Still very slow but it completes and works so guess I'm done. Never want to work with c again.

Completed the perl program in less than 25 minutes, having never written a line of perl in my life. In java I bet I could do it in like 5-7 minutes.

The most difficult part of the program is not having access to many higher
level concepts in the c stdlib. Not having a hashmap was really detrimental
cause I didn't feel like implementing one, so I used a really inefficient hack
with 2 arrays. Sorting was pretty easy to figure out, and make it work with
my hacky 2 indexes. Not having a proper split function was kind of troublesome.

The result of my programs are that they work, compile, and produce correct output.


